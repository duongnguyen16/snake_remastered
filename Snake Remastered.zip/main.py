import pygame
import random
import sys
import json

# ADDITIONAL LIBRARIES
from pyfader import IFader

pygame.init()

# VERSION IMPORT
version_type = "Release"
version_number = "1.0.1"

version_txt = pygame.font.Font('game_font.ttf', 15).render(
    "Snake Remastered " + version_number + " (" + version_type + ")", True, (192, 192, 192))

# COLOR SET

black = (0, 0, 0)
white = (255, 255, 255)
gray = (29, 27, 27)
orange = (250, 142, 0)
green = (0, 128, 0)
red = (255, 69, 0)
gold = (255, 215, 0)

# weigh, height of a screen
w, h = 810, 810

game_display = pygame.display.set_mode((1120, 840))

# SURFACE
screen = pygame.Surface((w, h))
setup = pygame.Surface((1090, 660))

# WINDOWS ICON/CAPTION
pygame.display.set_icon(pygame.image.load('./asset/game_icon.png'))
pygame.display.set_caption("Snake Remastered " + version_number + " -  " + version_type)

clock = pygame.time.Clock()

# TEXT SIZE SET
snake_size = 15
# snake_speed = 15
message_font_size = 18
score_font_size = 70
timer_font_size = 30
heart_font_size = 20

# FONT IMPORT
timer_font = pygame.font.Font('game_font.ttf', timer_font_size)
timer = pygame.font.Font('game_font.ttf', message_font_size)
score_font = pygame.font.Font('game_font.ttf', score_font_size)
message_font = pygame.font.Font('game_font.ttf', message_font_size)

added = 0

# load image
play_img = pygame.image.load('./asset/play_button_normal.png')
play_mention_img = pygame.image.load('./asset/play_button_mention.png')

# SNAKE IMPORT
snake = pygame.image.load('./asset/snake.png')

# FADE IMPORT
ingame_pause_bg = IFader("", "./asset/ingame_pause_bg.png")

# ANIMATION IMPORT
welcome_animation = IFader("", "./asset/welcome_fade.png")
welcome_loading_1 = IFader("", "./asset/welcome_loading_1.png")
welcome_loading_2 = IFader("", "./asset/welcome_loading_2.png")
welcome_loading_3 = IFader("", "./asset/welcome_loading_3.png")
welcome_done_img = pygame.image.load('./asset/welcome_done.png')


# GAME BACKGROUND IMPORT
game_bg = pygame.image.load('./asset/game_bg.png')

# MAIN MENU IMAGE IMPORT
main_menu_bg_img = pygame.image.load('./asset/main_menu_bg.png')
main_menu_custom_create_img = pygame.image.load('./asset/main_menu_custom_create.png')
main_menu_custom_create_mention_img = pygame.image.load('./asset/main_menu_custom_create_mention.png')
main_menu_leave_img = pygame.image.load('./asset/main_menu_leave.png')
main_menu_leave_mention_img = pygame.image.load('./asset/main_menu_leave_mention.png')
main_menu_shortcut_spr_img = pygame.image.load('./asset/main_menu_shortcut_spr.png')
main_menu_shortcut_spr_mention_img = pygame.image.load('./asset/main_menu_shortcut_spr_mention.png')
main_menu_shortcut_hardcore_img = pygame.image.load('./asset/main_menu_shortcut_hardcore.png')
main_menu_shortcut_hardcore_mention_img = pygame.image.load('./asset/main_menu_shortcut_hardcore_mention.png')
main_menu_shortcut_normal_img = pygame.image.load('./asset/main_menu_shortcut_normal.png')
main_menu_shortcut_normal_mention_img = pygame.image.load('./asset/main_menu_shortcut_normal_mention.png')

# SETUP IMAGE IMPORT
setup_bg_img = pygame.image.load('./asset/setup_main.png')
setup_go_back_ing = pygame.image.load('./asset/setup_go_back_normal.png')
setup_go_back_mention_img = pygame.image.load('./asset/setup_go_back_mention.png')
setup_singer_img = pygame.image.load('./asset/setup_mode_singer.png')
setup_singer_mention_img = pygame.image.load('./asset/setup_mode_singer_mention.png')
setup_multi_img = pygame.image.load('./asset/setup_mode_multi.png')
setup_multi_mention_img = pygame.image.load('./asset/setup_mode_multi_mention.png')
setup_main_img = pygame.image.load('./asset/setup_main.png')
setup_play_img = pygame.image.load('./asset/setup_play.png')
setup_play_mention_img = pygame.image.load('./asset/setup_play_mention.png')
setup_play_clicked_img = pygame.image.load('./asset/setup_play_clicked.png')
setup_loading_1_img = pygame.image.load('./asset/create_1.png')
setup_loading_2_img = pygame.image.load('./asset/create_2.png')
setup_loading_3_img = pygame.image.load('./asset/create_3.png')
setup_challenge_img = pygame.image.load('./asset/setup_challenge.png')
setup_challenge_choose_img = pygame.image.load('./asset/setup_challenge_choose.png')
setup_challenge_mention_img = pygame.image.load('./asset/setup_challenge_mention.png')
setup_FFA_img = pygame.image.load('./asset/setup_FFA.png')
setup_FFA_choose_img = pygame.image.load('./asset/setup_FFA_choose.png')
setup_FFA_mention_img = pygame.image.load('./asset/setup_FFA_mention.png')
setup_SPR_img = pygame.image.load('./asset/setup_SPR.png')
setup_SPR_choose_img = pygame.image.load('./asset/setup_SPR_choose.png')
setup_SPR_mention_img = pygame.image.load('./asset/setup_SPR_mention.png')
setup_down_blocked_img = pygame.image.load('./asset/setup_down_blocked.png')
setup_up_blocked_img = pygame.image.load('./asset/setup_up_blocked.png')
setup_duration_up_img = pygame.image.load('./asset/setup_duration_up.png')
setup_duration_up_mention_img = pygame.image.load('./asset/setup_duration_up_mention.png')
setup_duration_down_img = pygame.image.load('./asset/setup_duration_down.png')
setup_duration_down_mention_img = pygame.image.load('./asset/setup_duration_down_mention.png')
setup_heart_up_img = pygame.image.load('./asset/setup_heart_up.png')
setup_heart_up_mention_img = pygame.image.load('./asset/setup_heart_up_mention.png')
setup_heart_down_img = pygame.image.load('./asset/setup_heart_down.png')
setup_heart_down_mention_img = pygame.image.load('./asset/setup_heart_down_mention.png')
setup_random_img = pygame.image.load('./asset/setup_random.png')
setup_random_mention_img = pygame.image.load('./asset/setup_random_mention.png')
setup_speed_img = pygame.image.load('./asset/setup_speed.png')
setup_speed_mention_img = pygame.image.load('./asset/setup_speed_mention.png')
setup_speed_blocked_img = pygame.image.load('./asset/setup_speed_blocked.png')
setup_hardcore_true_img = pygame.image.load('./asset/setup_hardcore_true.png')
setup_hardcore_true_mention_img = pygame.image.load('./asset/setup_hardcore_true_mention.png')
setup_hardcore_false_img = pygame.image.load('./asset/setup_hardcore_false.png')
setup_hardcore_false_mention_img = pygame.image.load('./asset/setup_hardcore_false_mention.png')
setup_map_ffa_img = pygame.image.load('./asset/setup_map_ffa.png')
setup_map_ffa_mention_img = pygame.image.load('./asset/setup_map_ffa_mention.png')
setup_map_ffa_blocked_img = pygame.image.load('./asset/setup_map_ffa_blocked.png')
setup_map_cage_img = pygame.image.load('./asset/setup_map_cage.png')
setup_map_cage_mention_img = pygame.image.load('./asset/setup_map_cage_mention.png')
setup_map_cage_blocked_img = pygame.image.load('./asset/setup_map_cage_blocked.png')

# INGAME PAUSE IMPORT
ingame_pause_continue_img = pygame.image.load('./asset/ingame_pause_continue.png')
ingame_pause_continue_mention_img = pygame.image.load('./asset/ingame_pause_continue_mention.png')
ingame_pause_setting_img = pygame.image.load('./asset/ingame_pause_setting.png')
ingame_pause_setting_mention_img = pygame.image.load('./asset/ingame_pause_setting_mention.png')
ingame_pause_feedback_img = pygame.image.load('./asset/ingame_pause_feedback.png')
ingame_pause_feedback_mention_img = pygame.image.load('./asset/ingame_pause_feedback_mention.png')
ingame_pause_quit_img = pygame.image.load('./asset/ingame_pause_quit.png')
ingame_pause_quit_mention_img = pygame.image.load('./asset/ingame_pause_quit_mention.png')
ingame_main_img = pygame.image.load('./asset/ingame_main.png')
ingame_more_heart_img = pygame.image.load('./asset/ingame_more_heart.png')
ingame_bg_ffa_img = pygame.image.load('./asset/ingame_bg_ffa.png')
ingame_bg_cage_img = pygame.image.load('./asset/ingame_bg_cage.png')

game_lost_play_again_img = pygame.image.load('./asset/game_lost_play_again.png')
game_lost_play_again_mention_img = pygame.image.load('./asset/game_lost_play_again_mention.png')

game_lost_main_menu_img = pygame.image.load('./asset/game_lost_main_menu.png')
game_lost_main_menu_mention_img = pygame.image.load('./asset/game_lost_main_menu_mention.png')

# cage_border = pygame.image.load('./asset/ingame_cage_border.png')
# 


# ingame

# SHOW SNAKE FUNCTION
def show_snake(snake_size, snake_coord):
    for coord in snake_coord:
        # pygame.draw.rect(screen, (250,115,30), [coord[0], coord[1], snake_size, snake_size])
        screen.blit(snake, [coord[0], coord[1]])
        # pygame.draw.circle(screen, white, (coord[0] + snake_size / 2, coord[1] + snake_size / 2), snake_size / 2)


def ingame(animation_speed, max_heart, map, duration, hardcore):
    global added, ui, ingame_ms, food_lost

    # GAME INFO
    game_over = False
    game_lost = False

    # FOOD
    food = 240
    food_gain = 100
    if hardcore and not game_lost:
        food_lost = 0.25
    elif not game_lost:
        food_lost = 0.125

    # UI INGAME
    ingame_ui = "main"

    # INGAME TIME
    stop_watch = False

    # HEART INFO
    heart = max_heart

    # DEBUG
    debug = False

    # SNAKE COORD
    x = x_goal = w / 2
    y = y_goal = h / 2

    # SNAKE DIRECTION
    x_dir = 15
    y_dir = 0

    # GAME INFO
    score = 0

    # ingame milisecond
    ingame_ms = 0

    # snake information
    snake_coord = []
    snake_length = 1

    # gen food coord
    food_x = round(random.randrange(0, w - snake_size) / 15.0) * 15.0
    food_y = round(random.randrange(0, h - snake_size) / 15.0) * 15.0

    # BACKUP MOVEMENT
    x_backup = x_dir
    y_backup = y_dir

    # HEART NEW LEVEL
    heart_time = 0
    heart_x = 0
    heart_y = 0

    # level
    level_goal = 10
    level_num = 0
    level_additional = ""
    level_bar_now = 0
    level_point = 0

    # SNAKE INFO
    real_length = 0

    # UNLIMITED RESISTANCE IN MS
    pain_killer = 0

    # HEART - > MAX_HEART
    more_heart = 0

    # TIME CONTROl
    more = 0

    boost = False
    pause = False

    # PAUSE MENU FADE
    ingame_pause_bg.fadeIn(30)

    while not game_over:
        while ingame_ui == "main":

            # GET CURSOR
            cur_x = pygame.mouse.get_pos()[0]
            cur_y = pygame.mouse.get_pos()[1]

            # LEVEL
            if score == 0 and level_num != 1:
                level_point = 0
                level_goal = 5
                level_num = 1
                print("Level Num: " + str(level_num))
            elif score == 5 and level_num != 2:
                level_point = 0
                level_goal = 5
                level_num = 2
                level_bar_now = 0
                heart_time = 300
                if heart != -1 and not hardcore:
                    heart_x = round(random.randrange(0, w - snake_size) / 15.0) * 15.0
                    heart_y = round(random.randrange(0, w - snake_size) / 15.0) * 15.0
                print("Level Num: " + str(level_num))
            elif score == 10 and level_num != 3:
                level_point = 0
                level_goal = 15
                level_num = 3
                level_bar_now = 0
                heart_time = 300
                if heart != -1 and not hardcore:
                    heart_x = round(random.randrange(0, w - snake_size) / 15.0) * 15.0
                    heart_y = round(random.randrange(0, w - snake_size) / 15.0) * 15.0
                print("Level Num: " + str(level_num))
            elif score == 25 and level_num != 4:
                level_point = 0
                level_goal = 25
                level_num = 4
                level_bar_now = 0
                heart_time = 300
                if heart != -1 and not hardcore:
                    heart_x = round(random.randrange(0, w - snake_size) / 15.0) * 15.0
                    heart_y = round(random.randrange(0, w - snake_size) / 15.0) * 15.0
                print("Level Num: " + str(level_num))
            elif score == 50 and level_num != 5:
                level_point = 0
                level_goal = 50
                level_num = 5
                level_bar_now = 0
                heart_time = 300
                if heart != -1 and not hardcore:
                    heart_x = round(random.randrange(0, w - snake_size) / 15.0) * 15.0
                    heart_y = round(random.randrange(0, w - snake_size) / 15.0) * 15.0
                print("Level Num: " + str(level_num))
            elif score == 100 and level_num != 6:
                level_point = 0
                level_goal = 100
                level_num = 6
                level_bar_now = 0
                heart_time = 300
                if heart != -1 and not hardcore:
                    heart_x = round(random.randrange(0, w - snake_size) / 15.0) * 15.0
                    heart_y = round(random.randrange(0, w - snake_size) / 15.0) * 15.0
                print("Level Num: " + str(level_num))
            elif score == 200 and level_num != 7:
                level_point = 0
                level_goal = 300
                level_num = 7
                level_bar_now = 0
                heart_time = 300
                if heart != -1 and not hardcore:
                    heart_x = round(random.randrange(0, w - snake_size) / 15.0) * 15.0
                    heart_y = round(random.randrange(0, w - snake_size) / 15.0) * 15.0
                print("Level Num: " + str(level_num))
            elif score == 500 and level_num != 8:
                level_point = 0
                level_goal = 500
                level_num = 8
                level_bar_now = 0
                heart_time = 300
                if heart != -1 and not hardcore:
                    heart_x = round(random.randrange(0, w - snake_size) / 15.0) * 15.0
                    heart_y = round(random.randrange(0, w - snake_size) / 15.0) * 15.0
                print("Level Num: " + str(level_num))
            elif score == 1000 and level_num != 9:
                level_point = 0
                level_goal = 1000
                level_num = 9
                level_bar_now = 0
                heart_time = 300
                if heart != -1 and not hardcore:
                    heart_x = round(random.randrange(0, w - snake_size) / 15.0) * 15.0
                    heart_y = round(random.randrange(0, w - snake_size) / 15.0) * 15.0
                print("Level Num: " + str(level_num))
            elif score == 2000 and level_num != 10:
                level_point = 0
                level_goal = 3000
                level_num = 10
                level_additional = "(Max)"
                level_bar_now = 0
                heart_time = 300
                if heart != -1 and not hardcore:
                    heart_x = round(random.randrange(0, w - snake_size) / 15.0) * 15.0
                    heart_y = round(random.randrange(0, w - snake_size) / 15.0) * 15.0
                print("Level Num: " + str(level_num))

            # ADDITIONAL CODE
            # if score > 2000 and score % 500 == 0:
            #     heart_time = 300
            #     heart_x = round(random.randrange(0, w - snake_size) / 15.0) * 15.0
            #     heart_y = round(random.randrange(0, w - snake_size) / 15.0) * 15.0

            if debug:
                real_length += 1

            for event in pygame.event.get():
                # CONTROL (KEYBOARD)
                # /////////////////////////////////////////////////////////////////////////////////////////////////////
                if event.type == pygame.QUIT:
                    sys.exit()
                if event.type == pygame.KEYDOWN and not game_lost:
                    # NORMAL CONTROL
                    if event.key == pygame.K_a and x_dir != snake_size and y_dir != 0:
                        x_dir = -snake_size
                        y_dir = 0
                        if not stop_watch:
                            more = pygame.time.get_ticks()
                            stop_watch = True
                    elif event.key == pygame.K_w and x_dir != 0 and y_dir != snake_size:
                        x_dir = 0
                        y_dir = -snake_size
                        if not stop_watch:
                            more = pygame.time.get_ticks()
                            stop_watch = True
                    elif event.key == pygame.K_d and x_dir != -snake_size and y_dir != 0:
                        x_dir = snake_size
                        y_dir = 0
                        if not stop_watch:
                            more = pygame.time.get_ticks()
                            stop_watch = True
                    elif event.key == pygame.K_s and x_dir != 0 and y_dir != -snake_size:
                        x_dir = 0
                        y_dir = snake_size
                        if not stop_watch:
                            more = pygame.time.get_ticks()
                            stop_watch = True

                    # ESCAPE
                    elif event.key == pygame.K_ESCAPE and not game_lost:
                        x_backup = x_dir
                        y_backup = y_dir
                        x_dir = 0
                        y_dir = 0
                        ingame_ui = "pause"
                        pause = True
                        game_lost = True

                    # # FOR TEST ONLY
                    # elif event.key == pygame.K_UP and debug:
                    #     score += 1
                    #     level_point += 1
                    #     real_length += 1
                    #     # if heart < max_heart + 3:
                    #     #     heart += 1

                    # elif event.key == pygame.K_DOWN and debug:
                    #     score -= 1
                    #     level_point -= 1
                    #     real_length -= 1

                    # BOOST FUNCTION
                    elif event.key == pygame.K_LSHIFT or event.key == pygame.K_RSHIFT:
                        boost = True
                        # print("[OK] Movement: Active Boost!")

                    # DEBUG MODE
                    elif event.key == pygame.K_F3:
                        if debug:
                            debug = False
                        else:
                            debug = True
                if event.type == pygame.KEYUP:
                    if event.key == pygame.K_LSHIFT or event.key == pygame.K_RSHIFT:
                        boost = False
                    boost_time = 0
                # print("[OK] Movement: Deactive Boost!")

            # END OF CONTROL
            # /////////////////////////////////////////////////////////////////////////////////////////////////////

            #  INGAME TIME
            if stop_watch and not game_lost:
                ingame_ms = pygame.time.get_ticks() - more

            # MAP FUNCTION
            if map == "ffa":
                if x >= w:
                    x = -5
                    x_goal = 15
                elif x < 0:
                    x = w
                    x_goal = w
                if y >= h:
                    y_goal = 15
                    y = -5
                elif y < 0:
                    y_goal = h
                    y = h

            # HEART CONTROL
            if max_heart != 0:
                # DEATH - EAT MYSELF
                for coord in snake_coord[:-1]:
                    if coord == [x, y] and heart >= 1 and pain_killer == 0:
                        heart -= 1
                        pain_killer = 100
                # DEATH - MAP CAGE
                if map == "cage" and (x > w or x < 0 or y > h or y < 0) and heart > 0 and pain_killer == 0:
                    heart -= 1
                    pain_killer = 100
                    if x >= w:
                        x = -5
                        x_goal = 15
                    elif x < 0:
                        x = w
                        x_goal = w
                    if y >= h:
                        y_goal = 15
                        y = -5
                    elif y < 0:
                        y_goal = h
                        y = h

                # DEATH LIMIT
                if heart == 0:
                    game_lost = True

            # HEAD DIRCTION (NO ANIMATION)
            if not game_lost and x == x_goal and y == y_goal:
                x_goal += x_dir
                y_goal += y_dir

            # SNAKE_DIRECTION
            if not game_lost:
                if x < x_goal:
                    x += animation_speed
                elif x > x_goal:
                    x -= animation_speed
                else:
                    if y < y_goal:
                        y += animation_speed
                    elif y > y_goal:
                        y -= animation_speed

            # ANIMATION_SPEED
            if abs(x_goal - x) < animation_speed:
                x_goal = x

            if abs(y_goal - y) < animation_speed:
                y_goal = y

            if x == food_x and y == food_y:
                food_x = round(random.randrange(0, w - snake_size) / 15.0) * 15.0
                food_y = round(random.randrange(0, h - snake_size) / 15.0) * 15.0
                real_length += 1
                score += 1
                added = 3
                food += food_gain
                level_point += 1

            snake_length = 1 + real_length * (15 / animation_speed)
            heart_time -= 1

            if x_goal == heart_x and y_goal == heart_y and heart_time > 0:
                heart_time = 0
                if heart < max_heart + 3:
                    heart += 1

            # print("[Heart Food Time] " + str(heart_time))

            #   show display
            game_display.fill(black)

            if not game_lost:
                snake_coord.append([x, y])

            # SNAKE END CONTROL
            if len(snake_coord) > snake_length:
                del snake_coord[0]

            game_display.blit(ingame_main_img, [0, 0])
            if map == "ffa":
                screen.blit(ingame_bg_ffa_img, [0, 0])
            else:
                screen.blit(ingame_bg_cage_img, [0, 0])
            # layer 1
            if heart_time > 0:
                pygame.draw.circle(screen, red, (heart_x + snake_size / 2, heart_y + snake_size / 2),
                                   snake_size / 2 - 1)
            pygame.draw.circle(screen, white, (food_x + snake_size / 2, food_y + snake_size / 2), snake_size / 2 - 2)
            # pygame.draw.rect(screen, white, [food_x, food_y, snake_size, snake_size])
            # layer 2

            show_snake(snake_size, snake_coord)

            # SCOREBOARD AREA:
            # //////////////////////////////////////////////////////////////////////////////////////////////////////////

            second_all = int(ingame_ms / 1000)
            minutes = int(second_all / 60)
            second = int(second_all % 60)

            # TIME LEFT FUNCTION
            if duration != -1:
                if second_all == duration * 60:
                    game_lost = True

            if duration != -1:
                time_txt = timer_font.render(
                    str(minutes).rjust(2, "0") + ":" + str(str(second).rjust(2, "0")) + "/" + str(
                        str(duration).rjust(2, "0")) + ":00", True, white)
                game_display.blit(time_txt, [865, 74])
            else:
                time_txt = timer_font.render(str(minutes).rjust(2, "0") + ":" + str(str(second).rjust(2, "0")), True,
                                             white)
                game_display.blit(time_txt, [924, 74])

            # SCORE NUMBER
            if score < 100:
                score_txt = score_font.render(str(str(score).rjust(2, "0")), True, white)
                game_display.blit(score_txt, [922, 212])
            elif 100 <= score < 1000:
                score_txt = score_font.render(str(score), True, white)
                game_display.blit(score_txt, [898, 212])
            elif 1001 <= score < 10000:
                score_txt = score_font.render(str(score), True, white)
                game_display.blit(score_txt, [872, 212])
            else:
                score_k = int(score / 1000)
                score_txt = score_font.render(str(score_k) + "k", True, white)
                game_display.blit(score_txt, [900, 212])

            if heart != -1:
                heart_show = heart
                if heart > max_heart:
                    more_heart = heart - max_heart
                    heart_show = max_heart
                heart_txt = pygame.font.Font('game_font.ttf', 20).render(
                    str(str(int(heart_show)).rjust(2, "0")) + "/" + str(str(int(max_heart)).rjust(2, "0")), True, white)
                game_display.blit(heart_txt, [937, 407])

                if more_heart > 0:
                    game_display.blit(ingame_more_heart_img, [1028, 406])
                    more_heart_txt = pygame.font.Font('game_font.ttf', 15).render("+" + str(int(more_heart)), True, white)
                    game_display.blit(more_heart_txt, [1042, 410])
                more_heart = 0

            else:
                heart_txt = pygame.font.Font('game_font.ttf', 20).render(
                    "Unlimited", True, white)
                game_display.blit(heart_txt, [926, 407])


            # GAME LOST:
            if game_lost:
                pygame.draw.rect(screen, (50,50,50), [0, 740, 810, 70])
                # PLAY AGAIN
                if 15 + 7 <= cur_x <= 15 + 7 + 195 and 15 + 745 <= cur_y <= 15 + 745 + 60:
                    screen.blit(game_lost_play_again_mention_img, (7, 745))
                    if pygame.mouse.get_pressed() == (1, 0, 0):
                        ingame(5,max_heart,map, duration,hardcore)
                else:
                    screen.blit(game_lost_play_again_img, (7, 745))

                # BACK TO MAIN MENU
                if 15 + 210 <= cur_x <= 15 + 210 + 301 and 15 + 745 <= cur_y <= 15 + 745 + 60:
                    screen.blit(game_lost_main_menu_mention_img, (210, 745))
                    if pygame.mouse.get_pressed() == (1, 0, 0):
                        main_menu()
                else:
                    screen.blit(game_lost_main_menu_img, (210, 745))


            game_display.blit(screen, (15, 15))

            # FOOD BAR
            if food > 240:
                food = 240
            pygame.draw.rect(game_display, (240 - food, 240 - (240 - food), 0), [854, 651, food, 34])

            # LEVEL BAR
            level_txt = pygame.font.Font('game_font.ttf', 18).render(
                str("Lv. " + str(level_num) + " " + str(level_additional)), True, white)
            game_display.blit(level_txt, [892, 534])
            level_bar_goal = (level_point / level_goal) * 240
            if level_point <= 3000:
                if level_bar_now < level_bar_goal:
                    level_bar_now += 4
                if level_bar_goal < level_bar_now:
                    level_bar_now = level_bar_goal
                if not game_lost:
                    pygame.draw.rect(game_display, (30, 144, 255), [854, 567, level_bar_now, 34])
                elif heart == 0:
                    pygame.draw.rect(game_display, red, [854, 567, level_bar_now, 34])
                else:
                    pygame.draw.rect(game_display, (255, 255, 0), [854, 567, level_bar_now, 34])
            else:
                if not game_lost:
                    pygame.draw.rect(game_display, (30, 144, 255), [854, 567, 240, 34])
                elif heart == 0:
                    pygame.draw.rect(game_display, red, [854, 567, 240, 34])
                else:
                    pygame.draw.rect(game_display, (255,255,0), [854, 567, 240, 34])



            # END OF BAR
            # ////////////////////////////////////////////////////////////////////////////////////////////////////////

            # UPDATE DISPLAY
            pygame.display.update()
            
            # PAIN KILLER
            if pain_killer > 0:
                pain_killer -= 1

            # FOOD ENGINE
            if stop_watch and max_heart != -1 and not game_lost:
                food -= food_lost
                # SLOWER WHEN LOWER FOOD
            if max_heart != -1:
                if 60 < food <= 120:
                    clock.tick(45)
                    heart -= 0.150
                elif 30 <= food <= 60:
                    clock.tick(25)
                    heart -= 0.25
                elif 10 <= food < 30:
                    clock.tick(20)
                    heart -= 0.5
                elif 0 < food < 10:
                    clock.tick(10)
                    food_lost = 1
                elif food <= 0:
                    heart -= 1
                    food = 240
                    if hardcore:
                        food_lost = 0.25
                    else:
                        food_lost = 0.125

            # SPRINT
            if boost and not game_lost:
                if x < x_goal:
                    x += animation_speed
                elif x > x_goal:
                    x -= animation_speed
                else:
                    if y < y_goal:
                        y += animation_speed
                    elif y > y_goal:
                        y -= animation_speed
                if hardcore:
                    food -= 0.25
                else:
                    food -= 0.125

        while ingame_ui == "pause":

            # GET CURSOR POSITION
            cur_x = pygame.mouse.get_pos()[0]
            cur_y = pygame.mouse.get_pos()[1]

            ingame_pause_bg.draw(screen)
            game_display.blit(screen, [13, 13])

            # EVENT
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        ingame_ui = "main"
                        pause = False
                        game_lost = False
                        x_dir = x_backup
                        y_dir = y_backup
                        ui = "ingame"
            # game_display.blit(ingame_pause_bg_img, [0, 0])
            if 13 + 16 <= cur_x <= 13 + 16 + 200 and 13 + 485 <= cur_y <= 13 + 485 + 70:
                game_display.blit(ingame_pause_continue_mention_img, [16 + 13, 485 + 13])
                if pygame.mouse.get_pressed() == (1, 0, 0):
                    ingame_ui = "main"
                    pause = False
                    game_lost = False
                    x_dir = x_backup
                    y_dir = y_backup
                    ui = "ingame"
            else:
                game_display.blit(ingame_pause_continue_img, [16 + 13, 485 + 13])

            if 13 + 16 <= cur_x <= 13 + 16 + 244 and 13 + 565 <= cur_y <= 13 + 565 + 70:
                game_display.blit(ingame_pause_setting_mention_img, [16 + 13, 565 + 13])
                # if pygame.mouse.get_pressed() == (1, 0, 0):

            else:
                game_display.blit(ingame_pause_setting_img, [16 + 13, 565 + 13])

            if 13 + 16 <= cur_x <= 13 + 16 + 276 and 13 + 645 <= cur_y <= 13 + 645 + 70:
                game_display.blit(ingame_pause_feedback_mention_img, [16 + 13, 645 + 13])
                # if pygame.mouse.get_pressed() == (1, 0, 0):

            else:
                game_display.blit(ingame_pause_feedback_img, [16 + 13, 645 + 13])

            if 13 + 16 <= cur_x <= 13 + 16 + 299 and 13 + 725 <= cur_y <= 13 + 725 + 70:
                game_display.blit(ingame_pause_quit_mention_img, [16 + 13, 725 + 13])
                if pygame.mouse.get_pressed() == (1, 0, 0):
                    main_menu()

            else:
                game_display.blit(ingame_pause_quit_img, [16 + 13, 725 + 13])

            pygame.display.update()


# END OF INGAME
# //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


def desc(message):
    desc_txt = message_font.render(message, True, white)
    setup.blit(desc_txt, [35, 64])


# DIFFICULT LEVEL CALCULATOR
def check_difficulty(hardcore, duration, heart, speed):
    diff_score = 0
    if hardcore:
        return "Hard"
    if heart == 0:
        return "Easy"
    if 5 < duration < 20:
        diff_score += 3
    elif 20 <= diff_score:
        diff_score += 5
    if heart == 1:
        diff_score += 3
    elif 1 < heart <= 3:
        diff_score += 2
    elif 3 < heart <= 10:
        diff_score += 1
    if speed == 16:
        diff_score += 1
    elif speed == 32:
        diff_score += 3
    else:
        diff_score += 5
    if diff_score <= 3:
        return "Easy"
    elif 3 < diff_score <= 10:
        return "Average"
    else:
        return "Hard"


def main_menu():
    # global clock_tick_after_click

    # FOR RANDOM 
    rand_dur_min = 1
    rand_dur_max = 20
    rand_heart_min = 1
    rand_heart_max = 20

    # HARDCORE?
    hardcore = False

    # CONTROL PERMISSON
    duration_permission = True
    heart_permission = True
    speed_permission = True

    # UI NOW
    menu_ui = "main"

    # duration: time: 0: infinitive
    duration = 0

    # diff: freeforall(fff), cage(cage)
    type = "challenge"

    # live: 0: infinitive, 1: times
    heart = 0

    # score: -1: indinitive, >0: limited
    score = -1

    # speed: snake_speed
    speed = 1

    # mode: singer, multi
    mode = "singer"

    # map: ffa, cage
    map = "ffa"

    # animation
    animation_close = 0

    change_scence = False

    # loading
    loading_animation_1 = 800
    loading_animation_2 = 450
    loading_animation_3 = 150

    wait_ms = 1000

    block_key = False

    animation_ms = 5000
    times = 1

    cur_x = 0
    cur_y = 0

    while True:
        while menu_ui == "main":
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()
            cur_x = pygame.mouse.get_pos()[0]
            cur_y = pygame.mouse.get_pos()[1]
            game_display.fill(black)
            game_display.blit(main_menu_bg_img, (0, 0))

            # MAIN MENU ZONE


            # CREATE BUTTON
            if 262 <= cur_x <= 262 + 320 and 321 <= cur_y <= 321 + 61:
                game_display.blit(main_menu_custom_create_mention_img, (262, 321))
                if pygame.mouse.get_pressed() == (1, 0, 0):
                    menu_ui = "setup"
            else:
                game_display.blit(main_menu_custom_create_img, (262, 321))

            # SHORTCUT_RANDOM BUTTON
            if 58 <= cur_x <= 58 + 549 and 480 <= cur_y <= 480 + 80:
                game_display.blit(main_menu_shortcut_spr_mention_img, (58, 480))
                if pygame.mouse.get_pressed() == (1, 0, 0):
                    heart = 1
                    map = "ffa"
                    duration = -1
                    menu_ui = "creategame"
            else:
                game_display.blit(main_menu_shortcut_spr_img, (58, 480))

            # SHORTCUT_HARDCORE BUTTON 
            if 58 <= cur_x <= 58 + 549 and 560 <= cur_y <= 560 + 80:
                game_display.blit(main_menu_shortcut_hardcore_mention_img, (58, 560))
                if pygame.mouse.get_pressed() == (1, 0, 0):
                    heart = 1
                    map = "cage"
                    duration = -1
                    hardcore = True
                    menu_ui = "creategame"
            else:
                game_display.blit(main_menu_shortcut_hardcore_img, (58, 560))

            # SHORTCUT_NORMAL BUTTON
            if 58 <= cur_x <= 58 + 549 and 640 <= cur_y <= 640 + 80:
                game_display.blit(main_menu_shortcut_normal_mention_img, (58, 640))
                if pygame.mouse.get_pressed() == (1, 0, 0):
                    heart = 3
                    map = "ffa"
                    duration = -1
                    menu_ui = "creategame"
            else:
                game_display.blit(main_menu_shortcut_normal_img, (58, 640))

            # LEAVE ICON
            if 966 <= cur_x <= 966 + 134 and 770 <= cur_y <= 770 + 60:
                game_display.blit(main_menu_leave_mention_img, (966, 770))
                if pygame.mouse.get_pressed() == (1, 0, 0):
                    sys.exit()
            else:
                game_display.blit(main_menu_leave_img, (966, 770))

            main_menu_ver_txt = pygame.font.Font('game_font.ttf', 20).render(
                "Snake Remastered " + version_number + " (" + version_type + " )", True, white)
            game_display.blit(main_menu_ver_txt, [27, 785])

            pygame.display.update()

        while menu_ui == "setup":

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()
            if not block_key:
                cur_x = pygame.mouse.get_pos()[0]
                cur_y = pygame.mouse.get_pos()[1]
            else:
                cur_x = 0
                cur_y = 0
            game_display.fill(black)
            game_display.blit(game_bg, (0, 0))
            # go back
            # pygame.draw.rect(game_display, gray, [15, 15, 200, 60])

            if 15 <= cur_x <= 15 + 200 and 15 <= cur_y <= 15 + 60:
                game_display.blit(setup_go_back_mention_img, (15, 15))
                if pygame.mouse.get_pressed() == (1, 0, 0):
                    menu_ui = "main"
            else:
                game_display.blit(setup_go_back_ing, (15, 15))

            # main
            # game type: (In surface) 232.5 120
            #  + Challenge: 44, 217
            #  + FFA: 44 351
            #  + SPR: 44 485

            # setup surface: 15 90

            setup.fill(gray)
            setup.blit(setup_bg_img, (0, 0))
            if mode == "singer":
                # game mode change:
                if 15 + 705 <= cur_x <= 15 + 705 + 358 and 90 + 499 <= cur_y <= 90 + 499 + 52:
                    if hardcore:
                        setup.blit(setup_hardcore_true_mention_img, [705, 499])
                        if pygame.mouse.get_pressed() == (1, 0, 0):
                            hardcore = False
                            clock.tick(30)
                    else:
                        setup.blit(setup_hardcore_false_mention_img, [705, 499])
                        if pygame.mouse.get_pressed() == (1, 0, 0):
                            hardcore = True
                            clock.tick(30)
                    clock.tick(15)
                else:
                    if hardcore:
                        setup.blit(setup_hardcore_true_img, [705, 499])
                    else:
                        setup.blit(setup_hardcore_false_img, [705, 499])

                if type == "challenge":
                    if not hardcore:
                        heart_permission = False
                        heart = 1
                        duration_permission = True
                        map_permission = True
                        speed_permission = True
                    else:
                        heart_permission = False
                        heart = 1
                        duration_permission = True
                        map_permission = False
                        map = "cage"
                        speed_permission = False
                        speed = 4
                elif type == "FFA":
                    if not hardcore:
                        heart_permission = True
                        duration_permission = True
                        map_permission = True
                        speed_permission = True
                    else:
                        heart_permission = False
                        heart = 1
                        duration_permission = True
                        map_permission = False
                        map = "FFA"
                        speed_permission = False
                        speed = 4
                elif type == "SPR":
                    if not hardcore:
                        heart_permission = False
                        heart = 1
                        duration_permission = False
                        duration = 0
                        map_permission = True
                        speed_permission = True
                    else:
                        heart_permission = False
                        heart = 1
                        duration_permission = False
                        duration = 0
                        map_permission = False
                        map = "cage"
                        speed_permission = False
                        speed = 4

                if 15 + 44 <= cur_x <= 15 + 44 + 233 and 90 + 217 <= cur_y <= 90 + 120 + 217 and type != "challenge":
                    setup.blit(setup_challenge_mention_img, (44, 217))
                    if pygame.mouse.get_pressed() == (1, 0, 0):
                        type = "challenge"
                elif type == "challenge":
                    setup.blit(setup_challenge_choose_img, (44, 217))
                elif type != "challenge":
                    setup.blit(setup_challenge_img, (44, 217))

                if 15 + 44 <= cur_x <= 15 + 44 + 233 and 90 + 351 <= cur_y <= 90 + 120 + 351 and type != "FFA":
                    setup.blit(setup_FFA_mention_img, (44, 351))
                    if pygame.mouse.get_pressed() == (1, 0, 0):
                        type = "FFA"
                elif type == "FFA":
                    setup.blit(setup_FFA_choose_img, (44, 351))
                elif type != "FFA":
                    setup.blit(setup_FFA_img, (44, 351))

                if 15 + 44 <= cur_x <= 15 + 44 + 233 and 90 + 485 <= cur_y <= 90 + 120 + 485 and type != "SPR":
                    setup.blit(setup_SPR_mention_img, (44, 485))
                    if pygame.mouse.get_pressed() == (1, 0, 0):
                        type = "SPR"
                elif type == "SPR":
                    setup.blit(setup_SPR_choose_img, (44, 485))
                elif type != "SPR":
                    setup.blit(setup_SPR_img, (44, 485))

                # duration:
                if duration < 1:
                    duration_txt = message_font.render("Unlimited", True, white)
                else:
                    duration_txt = message_font.render(str(int(duration)) + " minutes", True, white)
                setup.blit(duration_txt, [442, 236])

                clock_tick_after_click = 8

                # DURATION SETUP
                if duration_permission:
                    if 15 + 348 <= cur_x <= 15 + 348 + 38 and 90 + 230 <= cur_y <= 90 + 230 + 38:
                        setup.blit(setup_duration_down_mention_img, (348, 230))
                        if pygame.mouse.get_pressed() == (1, 0, 0) and duration > 0:
                            duration -= 0.5
                            clock.tick(clock_tick_after_click)
                    else:
                        setup.blit(setup_duration_down_img, (348, 230))

                    if 15 + 614 <= cur_x <= 15 + 614 + 38 and 90 + 230 <= cur_y <= 90 + 230 + 38:
                        setup.blit(setup_duration_up_mention_img, (614, 230))
                        if pygame.mouse.get_pressed() == (1, 0, 0) and duration <= 99:
                            if duration < 1:
                                duration = 1
                            else:
                                duration += 1
                            clock.tick(clock_tick_after_click)
                    else:
                        setup.blit(setup_duration_up_img, (614, 230))
                else:
                    setup.blit(setup_down_blocked_img, (348, 230))
                    setup.blit(setup_up_blocked_img, (614, 230))


                # HEART SETUP
                if heart == 0:
                    heart_txt = message_font.render("Unlimited", True, white)
                else:
                    heart_txt = message_font.render(str(int(heart)) + " heart", True, white)
                setup.blit(heart_txt, [832, 236])

                if heart_permission:

                    if 15 + 735 <= cur_x <= 15 + 735 + 38 and 90 + 230 <= cur_y <= 90 + 230 + 38:
                        setup.blit(setup_heart_down_mention_img, (735, 230))
                        if pygame.mouse.get_pressed() == (1, 0, 0) and heart > 0:
                            heart -= 0.5
                            clock.tick(clock_tick_after_click)
                    else:
                        setup.blit(setup_heart_down_img, (735, 230))

                    if 15 + 1001 <= cur_x <= 15 + 1001 + 38 and 90 + 230 <= cur_y <= 90 + 230 + 38:
                        setup.blit(setup_heart_up_mention_img, (1001, 230))
                        if pygame.mouse.get_pressed() == (1, 0, 0) and heart <= 99:
                            if heart < 1:
                                heart = 1
                            else:
                                heart += 0.5
                            clock.tick(clock_tick_after_click)
                    else:
                        setup.blit(setup_heart_up_img, (1001, 230))
                else:
                    setup.blit(setup_down_blocked_img, (735, 230))
                    setup.blit(setup_up_blocked_img, (1001, 230))

                # MAP SETUP
                if map_permission:
                    if 15 + 318 <= cur_x <= 15 + 318 + 358 and 90 + 330 <= cur_y <= 90 + 330 + 221:
                        if map == "ffa":
                            setup.blit(setup_map_ffa_mention_img, [318, 330])
                        else:
                            setup.blit(setup_map_cage_mention_img, [318, 330])

                        if pygame.mouse.get_pressed() == (1, 0, 0):
                            if map == "ffa":
                                map = "cage"
                            else:
                                map = "ffa"
                            clock.tick(8)
                        clock.tick(15)
                    else:
                        if map == "ffa":
                            setup.blit(setup_map_ffa_img, [318, 330])
                        else:
                            setup.blit(setup_map_cage_img, [318, 330])

                else:
                    if map == "ffa":
                        setup.blit(setup_map_ffa_blocked_img, [318, 330])
                    else:
                        setup.blit(setup_map_cage_blocked_img, [318, 330])

                #  RANDOM BUTTON
                if 15 + 318 <= cur_x <= 15 + 318 + 745 and 90 + 567 <= cur_y <= 90 + 567 + 52:
                    setup.blit(setup_random_mention_img, (318, 567))
                    if pygame.mouse.get_pressed() == (1, 0, 0):
                        if heart_permission:
                            heart = random.randrange(rand_heart_min, rand_heart_max, 1)
                        if duration_permission:
                            duration = random.randrange(rand_dur_min, rand_dur_max, 1)
                        clock.tick(clock_tick_after_click)
                        menu_ui = "creategame"
                else:
                    setup.blit(setup_random_img, (318, 567))

                # diff
                diff_color = white
                title_1_txt = pygame.font.Font('game_font.ttf', 20).render("Difficulty: ", True, white)
                setup.blit(title_1_txt, [835, 24])
                if (check_difficulty(hardcore, duration, heart, speed)) == "Hard":
                    diff_color = red
                elif (check_difficulty(hardcore, duration, heart, speed)) == "Average":
                    diff_color = orange
                elif (check_difficulty(hardcore, duration, heart, speed)) == "Easy":
                    diff_color = green
                title_2_txt = pygame.font.Font('game_font.ttf', 20).render(
                    check_difficulty(hardcore, duration, heart, speed), True, diff_color)
                setup.blit(title_2_txt, [960, 24])

            # TITLE
            if 15 + 44 <= cur_x <= 15 + 44 + 233 and 90 + 217 <= cur_y <= 90 + 120 + 217:
                desc("Challenge Mode: Limited by Time")
            else:
                desc("Setup: Control your game mode, duration and more!")

            # END OF SETUP SURFACE

            # /////////////////////////////////////////////////////////////////////////////////////////////////////////

            game_display.blit(setup, (15, 90))

            # pygame.draw.rect(game_display, gray, [15, 90, 1090, 660])
            # next
            # pygame.draw.rect(game_display, gray, [875, 765, 230, 60])
            # setup.blit(setup_play_img, (865, 765))

            # PLAY BUTTON
            if 875 <= cur_x <= 1105 + 200 and 765 <= cur_y <= 820 + 60:
                game_display.blit(setup_play_mention_img, (865, 765))
                if pygame.mouse.get_pressed() == (1, 0, 0):
                    game_display.blit(setup_play_clicked_img, (865, 765))
                    animation_close = 840
                    # pygame.draw.rect(game_display, gray, [0, 0, 1120, 840])
                    # menu_ui = "main"
            else:
                game_display.blit(setup_play_img, (865, 765))

            # LOADING ANIMATION
            if animation_close > 0 and animation_close != 0:
                if animation_close >= 600:
                    out = 15
                elif 200 <= animation_close <= 600:
                    out = 5
                else:
                    out = 10
                if animation_close > 0:
                    pygame.draw.rect(game_display, (192, 192, 192), [0, 827, 1120 - animation_close, 12])
                animation_close -= out

                if animation_close <= 2:
                    change_scence = True
                    menu_ui = "creategame"
            if change_scence:
                pygame.draw.rect(game_display, gray, [0, 0, 1120, 840])

            #     game desc

            pygame.display.update()
            # clock.tick(1)

        # GAME INTRO
        while menu_ui == "creategame":
            block_key = True
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()
            if wait_ms == 0:
                game_display.fill(gray)
                if loading_animation_1 > 0:
                    game_display.blit(setup_loading_1_img, (0, 0))
                    loading_animation_1 -= 1
                if loading_animation_1 == 0 and loading_animation_2 > 0:
                    game_display.blit(setup_loading_2_img, (0, 0))
                    loading_animation_2 -= 1
                if loading_animation_1 == 0 and loading_animation_2 == 0 and loading_animation_3 > 0:
                    game_display.blit(setup_loading_3_img, (0, 0))
                    loading_animation_3 -= 1
                if loading_animation_1 == loading_animation_2 == loading_animation_3 == 0:
                    if duration == 0:
                        duration = -1
                    ingame(5, int(heart), map, int(duration), hardcore)
            else:
                wait_ms -= 5

            pygame.display.update()


        # ADDED SOON - not error

        # GAME INTRO - NOT ADDED


        # while menu_ui == "welcome":
        #     # block_key = True
        #     # game_display.fill(black)
        #     # print("[Welcome] Loading: " + str(animation_ms))
        #     for event in pygame.event.get():
        #         if event.type == pygame.QUIT:
        #             sys.exit()
        #
        #     if animation_ms > 0:
        #         welcome_loading_1.fadeIn(1)
        #         welcome_loading_2.fadeIn(1)
        #         welcome_loading_3.fadeIn(1)
        #         if 0 <= times < 80:
        #             welcome_loading_1.draw(game_display)
        #             times += 1
        #         elif 80 <= times < 160:
        #             welcome_loading_2.draw(game_display)
        #             times += 1
        #         elif 160 <= times:
        #             welcome_loading_3.draw(game_display)
        #             times += 1
        #         animation_ms -= 10
        #     elif -200 <= animation_ms <= 0:
        #         game_display.blit(welcome_done_img, (0, 0))
        #         animation_ms -= 1
        #     if animation_ms == -200:
        #         game_display.fill(black)
        #         menu_ui = "main"
        #         continue
        #     game_display.blit(version_txt, [15, 15])
        #     pygame.display.update()


main_menu()

# FAST STARTUP
# ingame(5, 1, "ffa", -1, False)
